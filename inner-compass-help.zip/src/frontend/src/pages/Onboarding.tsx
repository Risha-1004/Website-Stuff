import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useCompleteOnboarding } from "@/hooks/useProfile";
import type { Gender } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";

const GENDER_OPTIONS: { value: Gender; label: string; emoji: string }[] = [
  { value: "woman", label: "Woman", emoji: "🌸" },
  { value: "man", label: "Man", emoji: "🌿" },
  { value: "nonBinary", label: "Non-binary", emoji: "🌈" },
  { value: "preferNotToSay", label: "Prefer not to say", emoji: "✨" },
];

export default function Onboarding() {
  const navigate = useNavigate();
  const { mutateAsync: completeOnboarding, isPending } =
    useCompleteOnboarding();
  const [selectedGender, setSelectedGender] = useState<Gender | null>(null);
  const [trackPeriod, setTrackPeriod] = useState(false);

  const handleSubmit = async () => {
    if (!selectedGender) return;
    try {
      await completeOnboarding({
        hasPeriods: trackPeriod,
        gender: selectedGender,
      });
      navigate({ to: "/dashboard" });
    } catch {
      toast.error("Something went wrong. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="mx-auto mb-4 w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
            <span className="text-2xl" role="img" aria-label="compass">
              🧭
            </span>
          </div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">
            Welcome to Inner Compass
          </h1>
          <p className="text-muted-foreground text-sm">
            A couple of quick questions to personalise your experience.
          </p>
        </div>

        <Card className="p-6 shadow-elevated border-border space-y-6">
          {/* Gender question */}
          <div>
            <h2 className="text-xl font-display font-semibold text-foreground mb-1">
              What is your gender?
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              Your answer helps us tailor your experience. All identities are
              welcome here.
            </p>
            <div className="grid grid-cols-2 gap-3">
              {GENDER_OPTIONS.map(({ value, label, emoji }) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setSelectedGender(value)}
                  className={`p-4 rounded-xl border-2 text-center transition-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                    selectedGender === value
                      ? "border-primary bg-primary/10 text-primary font-medium"
                      : "border-border bg-card text-foreground hover:border-primary/40 hover:bg-primary/5"
                  }`}
                  data-ocid={`onboarding.gender.${value}`}
                  aria-pressed={selectedGender === value}
                >
                  <span className="text-2xl block mb-1">{emoji}</span>
                  <span className="text-sm">{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Period tracker toggle */}
          <div className="rounded-xl border border-border bg-muted/40 p-4 flex items-start gap-4">
            <Switch
              id="period-toggle"
              checked={trackPeriod}
              onCheckedChange={setTrackPeriod}
              data-ocid="onboarding.period_toggle"
            />
            <div className="flex-1 min-w-0">
              <Label
                htmlFor="period-toggle"
                className="font-medium text-foreground cursor-pointer"
              >
                Enable period tracker
              </Label>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                Turn this on to track your cycle. You can change this anytime in
                Settings.
              </p>
            </div>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={!selectedGender || isPending}
            className="w-full rounded-xl"
            size="lg"
            data-ocid="onboarding.submit_button"
          >
            {isPending ? (
              <>
                <Loader2 size={16} className="animate-spin mr-2" />
                Setting up your space…
              </>
            ) : (
              "Continue to Dashboard"
            )}
          </Button>

          <p className="text-center text-xs text-muted-foreground">
            You can update your preferences anytime in Settings.
          </p>
        </Card>
      </motion.div>
    </div>
  );
}
